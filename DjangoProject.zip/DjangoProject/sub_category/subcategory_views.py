from django.shortcuts import render, redirect

from sub_category.models import *


# Create your views here.
def load_subcategory(request):
    category_list = CategoryVo.objects.all()
    return render(request, "addsubCategory.html",
                  context={"category_list": category_list})


def insert_subcategory(request):
    subcategory_category_id = request.POST.get("category_id")
    print("subcategory_category_id>>>>>>>>", subcategory_category_id)
    subcategory_name = request.POST.get("subCategoryName")
    subcategory_description = request.POST.get("subCategoryDescription")
    category_vo = CategoryVo.objects.get(category_id=subcategory_category_id)
    subcategory_vo = SubcategoryVo()
    subcategory_vo.subcategory_category_vo = category_vo
    subcategory_vo.subcategory_name = subcategory_name
    subcategory_vo.subcategory_description = subcategory_description
    subcategory_vo.save()

    return redirect("view_subcategory")


def view_subcategoty(request):
    category_list = SubcategoryVo.objects.all()
    print(category_list)
    return render(request, "viewsubcategory.html",
                  context={"category_list": category_list})


def delete_subcategory(request):
    subcategory_vo = SubcategoryVo()
    subcategory_id = request.GET.get("subcategory_id")
    subcategory_vo.subcategory_id = subcategory_id
    subcategory_vo.delete()
    return redirect('view_subcategory')


def edit_subcategoty(request):
    subcategory_id = request.GET.get("subcategory_id")
    subcategory_vo_list = SubcategoryVo.objects.filter(
        subcategory_id=subcategory_id).all()
    # print(category_list)
    category_vo_list = CategoryVo.objects.all()
    print("<<<<<<<<<<<<<<<<<<<<<<<<", category_vo_list)
    print("<<<<<<<<<<<<<<<<<<<<<<<<", subcategory_vo_list)
    return render(request, "editsubcaegory.html",
                  context={"category_list": category_vo_list,
                           "subcategory_list": subcategory_vo_list})


def update_subcategory(request):
    subcategory_vo = SubcategoryVo()
    subcategory_category_id = request.POST.get("categoryId")
    print("subcategory_category_id>>>>>>>>", subcategory_category_id)
    subcategory_name = request.POST.get("subCategoryName")
    subcategory_description = request.POST.get("subCategoryDescription")
    subcategory_id = request.POST.get("subCategoryId")

    category_vo = CategoryVo.objects.get(category_id=subcategory_category_id)
    subcategory_vo.subcategory_category_vo = category_vo
    subcategory_vo.subcategory_id = subcategory_id
    subcategory_vo.subcategory_name = subcategory_name
    subcategory_vo.subcategory_description = subcategory_description
    subcategory_vo.save()
    return redirect("view_subcategory")
