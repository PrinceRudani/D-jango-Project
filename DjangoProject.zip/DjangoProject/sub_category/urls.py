from django.urls import path

from sub_category import subcategory_views

urlpatterns = [
    path('load_subcategory/', subcategory_views.load_subcategory,
         name="load_subcategory"),
    path('insert_subcategory/', subcategory_views.insert_subcategory,
         name="insert_subcategory"),
    path('view_subcategory/', subcategory_views.view_subcategoty,
         name="view_subcategory"),
    path('delete_subcategory/', subcategory_views.delete_subcategory,
         name="delete_subcategory"),
    path('edit_subcategory/', subcategory_views.edit_subcategoty,
         name="edit_subcategory"),
    path('update_subcategory/', subcategory_views.update_subcategory,
         name="update_subcategory"),
]
