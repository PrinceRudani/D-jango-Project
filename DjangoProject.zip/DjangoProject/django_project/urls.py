from django.urls import path, include

urlpatterns = [
    # path('admin/', admin.site.urls),
    path('', include('category.urls')),
    path('', include('sub_category.urls')),
    path('', include('product.urls')),
]
