from django.urls import path

from category import category_views

# from category.views import *
urlpatterns = [
    path('', category_views.menupage, name="menupage"),
    path('load_category/', category_views.load_category, name="load_category"),
    path('insert_category/', category_views.insert_category,
         name="insert_category"),
    path('view_category/', category_views.view_category, name="view_category"),
    path('edit_category/', category_views.edit_category, name="edit_category"),
    path('delete_category/', category_views.delete_category,
         name="delete_category"),
    path('update_category/', category_views.update_category,
         name="update_category")
]
