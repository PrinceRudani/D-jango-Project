from django.shortcuts import render, redirect

from category.models import *


def load_category(request):
    return render(request, "addCategory.html")


def menupage(request):
    return render(request, "menupage.html")


def insert_category(request):
    category_vo = CategoryVo()
    category_vo.category_name = request.POST.get('CategoryName')
    category_vo.category_description = request.POST.get('CategoryDescription')
    category_vo.save()
    return redirect("view_category")


def view_category(request):
    category_list = CategoryVo.objects.all()
    return render(request, "viewCategory.html",
                  {"category_list": category_list})


def edit_category(request):
    category_id = request.GET.get("category_id")
    category_list = CategoryVo.objects.filter(category_id=category_id).all()
    print(category_list)
    return render(request, "editCategory.html",
                  context={"category_list": category_list})


def delete_category(request):
    category_vo = CategoryVo()
    category_vo.category_id = request.GET.get("category_id")
    category_vo.delete()
    return redirect('view_category')


def update_category(request):
    category_name = request.POST.get("CategoryName")
    category_description = request.POST.get("CategoryDescription")
    category_id = request.POST.get("category_id")
    category_vo = CategoryVo()
    category_vo.category_id = category_id
    category_vo.category_name = category_name
    category_vo.category_description = category_description
    category_vo.save()
    return redirect("view_category")
