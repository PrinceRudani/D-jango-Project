from django.db import models

from category.models import CategoryVo
from sub_category.models import SubcategoryVo


class ProductVO(models.Model):
    product_id = models.AutoField(db_column="product_id", primary_key=True,
                                  null=False)
    product_name = models.CharField(db_column="product_name", max_length=50,
                                    default="", null=False)
    product_description = models.TextField(db_column="product_description",
                                           max_length=500, default="",
                                           null=False)
    product_quantity = models.IntegerField(db_column="product_quantity",
                                           null=False)
    product_price = models.IntegerField(db_column="product_price", null=False)
    product_image = models.ImageField(
        upload_to='static/adminResources/product/', db_column="product_image")
    product_category_vo = models.ForeignKey(CategoryVo,
                                            on_delete=models.CASCADE,
                                            db_column="product_category_id")
    product_subcategory_vo = models.ForeignKey(SubcategoryVo,
                                               on_delete=models.CASCADE,
                                               db_column="product_subcategory_id")

    def __str__(self):
        return '{} {} {} {}'.format(self.product_name,
                                    self.product_description,
                                    self.product_quantity,
                                    self.product_price)

    def __as_dict__(self):
        return {
            "product_id": self.product_id,
            "product_name": self.product_name,
            "product_description": self.product_description,
            "product_quantity": self.product_quantity,
            "product_price": self.product_price,
            "product_image": self.product_image,
            "product_category_vo": self.product_category_vo,
            "product_subcategory_vo": self.product_subcategory_vo,
        }

    class Meta:
        db_table = "product_table"
