from django.urls import path

from product import product_views

urlpatterns = [
    path('load_pruduct/', product_views.load_pruduct, name='load_pruduct'),
    path('ajax_product/', product_views.ajax_product, name='ajax_product'),
    path('insert_product/', product_views.insert_product,
         name="insert_product"),
    path('view_product/', product_views.view_product, name="view_product"),
    path('delete_product/', product_views.delete_product,
         name="delete_product"),
    path('update_dataproduct/', product_views.update_dataproduct,
         name="update_dataproduct"),
    path('edit_dataproduct/', product_views.edit_dataproduct,
         name="edit_dataproduct")

]
