import json
import os

from django.forms import model_to_dict
from django.http import HttpResponse
from django.shortcuts import render, redirect

from category.models import CategoryVo
from product.models import ProductVO
from sub_category.models import SubcategoryVo

BASE_DIR = os.path.join(os.path.dirname(__file__), '..')


# Create your views here.
def load_pruduct(request):
    product_vo_list = CategoryVo.objects.all()
    return render(request, 'addProduct.html',
                  context={'product_vo_list': product_vo_list})


def ajax_product(request):
    category_id = request.GET.get('productCategoryId')

    category_vo = CategoryVo.objects.get(category_id=category_id)
    subcategory_vo_list = SubcategoryVo.objects.filter(
        subcategory_category_vo=category_vo)
    json_subcategory_vo_list = []
    for i in subcategory_vo_list:
        subcategory_vo_dict = model_to_dict(i)
        json_subcategory_vo_list.append(subcategory_vo_dict)
    dump = json.dumps(json_subcategory_vo_list)
    return HttpResponse(dump, content_type='application/json')


def insert_product(request):
    product_vo = ProductVO()
    product_category_id = request.POST.get('productCategoryId')
    product_subcategory_id = request.POST.get('productSubCategoryId')
    product_vo.product_name = request.POST.get('product_name')
    product_vo.product_description = request.POST.get('product_description')
    product_vo.product_price = request.POST.get('product_price')
    product_vo.product_quantity = request.POST.get('product_quantity')
    product_vo.product_image = request.FILES['productImage']

    category_vo = CategoryVo.objects.get(category_id=product_category_id)
    subcategory_vo = SubcategoryVo.objects.get(
        subcategory_id=product_subcategory_id)
    product_vo.product_category_vo = category_vo
    product_vo.product_subcategory_vo = subcategory_vo
    product_vo.save()

    return redirect('/view_product')


def view_product(request):
    product_vo_list = ProductVO.objects.all()
    return render(request, 'viewProduct.html',
                  context={'product_vo_list': product_vo_list})


def delete_product(request):
    product_id = request.GET.get('product_Id')
    product_vo_object = ProductVO.objects.get(product_id=product_id)
    product_image_path = product_vo_object.product_image
    if os.path.exists(BASE_DIR + product_image_path.url):
        os.remove(BASE_DIR + product_image_path.url)
    product_vo_object.delete()
    return redirect('/view_product')


def edit_dataproduct(request):
    product_id = request.GET.get('productId')
    product_vo_list = ProductVO.objects.get(product_id=product_id)
    category_vo_list = CategoryVo.objects.all()
    context = {'data_one': product_vo_list,
               'category_vo_list': category_vo_list}
    return render(request, "editProductdata.html", context)


def update_dataproduct(request):
    product_id = request.POST.get('productId')
    product_category_id = request.POST.get('productCategoryId')
    product_subcategory_id = request.POST.get('ProductSubCategoryId')

    category_vo = CategoryVo.objects.get(category_id=product_category_id)
    subcategory_vo = SubcategoryVo.objects.get(
        subcategory_id=product_subcategory_id)
    product_vo = ProductVO.objects.get(product_id=product_id)

    product_vo.product_name = request.POST.get('ProductName')
    product_vo.product_description = request.POST.get('ProductDescription')
    product_vo.product_price = request.POST.get('ProductPrice')
    product_vo.product_quantity = request.POST.get('ProductQuantity')
    product_vo.product_category_id = category_vo
    product_vo.product_subcategory_id = subcategory_vo
    product_vo.save()
    return redirect('/view_product')
